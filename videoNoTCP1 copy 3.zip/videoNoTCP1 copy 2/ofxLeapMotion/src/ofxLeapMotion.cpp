/*
 *  ofxLeapMotion.cpp
 *  ofxLeapMotion
 *
 *  Created by theo on 1/3/13.
 *  Copyright 2013 __MyCompanyName__. All rights reserved.
 *
 */

#include "ofxLeapMotion.h"

